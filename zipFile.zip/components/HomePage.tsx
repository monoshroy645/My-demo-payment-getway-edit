
import React, { useState, useEffect, useRef } from 'react';

interface HomePageProps {
  onStart: () => void;
}

const HomePage: React.FC<HomePageProps> = ({ onStart }) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [showIndicator, setShowIndicator] = useState(false);
  const topButtonRef = useRef<HTMLButtonElement>(null);

  const slides = [
    {
      url: 'https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?auto=format&fit=crop&q=80&w=1600&h=600',
      title: 'আপনার স্বপ্ন পূরণে আমরা',
      desc: '১ লক্ষ টাকা পর্যন্ত লোন নিন এবং আপনার ব্যবসার পরিধি বৃদ্ধি করুন।',
    },
    {
      url: 'https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?auto=format&fit=crop&q=80&w=1600&h=600',
      title: 'দ্রুত অনুমোদন ও পেমেন্ট',
      desc: 'যাচাইকরণ শেষ হওয়ার কয়েক মিনিটের মধ্যেই আপনার একাউন্টে টাকা পৌঁছে যাবে।'
    }
  ];

  useEffect(() => {
    // Slider timer
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);

    // Auto-scroll to top button after a short delay
    const scrollTimer = setTimeout(() => {
      if (topButtonRef.current) {
        topButtonRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
        
        // Wait for the smooth scroll to finish before starting the indicator animation
        setTimeout(() => {
          setShowIndicator(true);
        }, 1000);
      }
    }, 1500);

    return () => {
      clearInterval(timer);
      clearTimeout(scrollTimer);
    };
  }, [slides.length]);

  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % slides.length);
  const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);

  return (
    <div className="max-w-6xl mx-auto animate-fade-in">
      {/* Hero Slider */}
      <div className="relative w-full h-[300px] md:h-[450px] rounded-3xl overflow-hidden shadow-2xl mb-12 group">
        {slides.map((slide, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
              index === currentSlide ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-transparent z-10"></div>
            <img
              src={slide.url}
              alt={slide.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 z-20 flex flex-col justify-center px-8 md:px-16">
              <h2 className="text-3xl md:text-5xl font-black text-white mb-4 leading-tight drop-shadow-lg">
                {slide.title}
              </h2>
              <p className="text-lg md:text-xl text-gray-100 mb-8 max-w-lg drop-shadow-md font-medium">
                {slide.desc}
              </p>
              <div>
                <button
                  onClick={onStart}
                  className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-full shadow-lg transform transition hover:scale-105 active:scale-95 inline-flex items-center space-x-2"
                >
                  <span>আবেদন শুরু করুন</span>
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                  </svg>
                </button>
              </div>
            </div>
          </div>
        ))}

        {/* Navigation Arrows */}
        <button
          onClick={prevSlide}
          className="absolute left-4 top-1/2 -translate-y-1/2 z-30 p-2 bg-white/20 hover:bg-white/40 text-white rounded-full backdrop-blur-md transition opacity-0 group-hover:opacity-100"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        <button
          onClick={nextSlide}
          className="absolute right-4 top-1/2 -translate-y-1/2 z-30 p-2 bg-white/20 hover:bg-white/40 text-white rounded-full backdrop-blur-md transition opacity-0 group-hover:opacity-100"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
          </svg>
        </button>

        {/* Indicators */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-30 flex space-x-2">
          {slides.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-3 h-3 rounded-full transition-all ${
                index === currentSlide ? 'bg-white w-8' : 'bg-white/50 hover:bg-white/80'
              }`}
            />
          ))}
        </div>
      </div>

      <div className="text-center mb-12 px-4 flex flex-col items-center">
        {/* Top Application Button with Indicator */}
        <button
          ref={topButtonRef}
          onClick={onStart}
          className={`bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 px-10 rounded-2xl shadow-xl transform transition hover:scale-105 active:scale-95 text-xl mb-8 flex items-center justify-center space-x-3 ${showIndicator ? 'animate-indicator' : ''}`}
        >
          <span className="flex items-center">লোন আবেদন করুন</span>
        </button>

        <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4 leading-tight">
          সহজ শর্তে এবং দ্রুত সময়ে <br />
          <span className="text-blue-600">পার্সোনাল লোন পান</span>
        </h1>
        <p className="text-md text-gray-600 max-w-2xl mx-auto mb-8">
          আমাদের প্ল্যাটফর্মের মাধ্যমে আপনি ঘরে বসেই বিকাশের লেনদেনের ওপর ভিত্তি করে ১,০০,০০০ টাকা পর্যন্ত লোন পেতে পারেন।
        </p>
        
        {/* Secondary Application Button */}
        <button
          onClick={onStart}
          className="bg-gray-100 hover:bg-gray-200 text-blue-700 font-bold py-4 px-10 rounded-2xl shadow-md transform transition hover:scale-105 active:scale-95 text-lg flex items-center justify-center mx-auto space-x-3 border border-blue-100"
        >
          <span className="flex items-center">লোন আবেদন করুন</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12 px-4">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 text-center hover:shadow-md transition">
          <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <h3 className="font-bold text-gray-800 mb-2">দ্রুত প্রসেসিং</h3>
          <p className="text-sm text-gray-600">মাত্র ৫ মিনিটে আপনার আবেদনটি যাচাই করা হয়।</p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 text-center hover:shadow-md transition">
          <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
            </svg>
          </div>
          <h3 className="font-bold text-gray-800 mb-2">সম্পূর্ণ নিরাপদ</h3>
          <p className="text-sm text-gray-600">আপনার ব্যক্তিগত তথ্যের গোপনীয়তা আমাদের সর্বোচ্চ অগ্রাধিকার।</p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 text-center hover:shadow-md transition">
          <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
            </svg>
          </div>
          <h3 className="font-bold text-gray-800 mb-2">কম সুদ</h3>
          <p className="text-sm text-gray-600">বাজারের সবচেয়ে আকর্ষণীয় সুদের হারে ঋণ প্রদান করা হয়।</p>
        </div>
      </div>

      <div className="bg-blue-50 p-8 rounded-3xl border border-blue-100 mx-4 mb-16">
        <h2 className="text-2xl font-bold text-blue-900 mb-6">লোন পাওয়ার ধাপসমূহ:</h2>
        <ul className="space-y-6 mb-8">
          <li className="flex items-start space-x-4">
            <span className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-lg font-bold mt-1 shadow-md">১</span>
            <p className="text-gray-700 text-lg">আবেদন ফরমে আপনার ব্যক্তিগত এবং ঋণের তথ্য প্রদান করুন।</p>
          </li>
          <li className="flex items-start space-x-4">
            <span className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-lg font-bold mt-1 shadow-md">২</span>
            <p className="text-gray-700 text-lg">বিকাশ নম্বর প্রদান করে আপনার আর্থিক লেনদেন প্রোফাইল যাচাই করুন।</p>
          </li>
          <li className="flex items-start space-x-4">
            <span className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-lg font-bold mt-1 shadow-md">৩</span>
            <p className="text-gray-700 text-lg">যাচাই শেষে অনুমোদন পেলে স্বল্প প্ল্যাটফর্ম ফি প্রদান করে লোন গ্রহণ করুন।</p>
          </li>
        </ul>

        <div className="space-y-4 border-t border-blue-100 pt-8">
          <div className="grid grid-cols-1 gap-4">
            <button
              onClick={onStart}
              className="flex items-center justify-center space-x-3 bg-pink-600 hover:bg-pink-700 text-white font-bold py-4 rounded-2xl shadow-lg transform transition hover:scale-105 active:scale-95"
            >
              <span className="text-xl">বিকাশ দিয়ে আবেদন</span>
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z" />
              </svg>
            </button>
          </div>
          
          <button
            onClick={onStart}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-2xl shadow-lg transform transition hover:scale-105 active:scale-95 text-xl flex items-center justify-center"
          >
            লোন আবেদন করুন
          </button>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
