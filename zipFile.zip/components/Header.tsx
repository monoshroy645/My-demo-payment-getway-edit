
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-white shadow-sm border-b border-gray-100 z-50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="flex items-center justify-center">
            <img 
              src="https://i.postimg.cc/0j6qxP8Q/IMG-20260205-090841.jpg" 
              alt="Logo" 
              className="h-10 w-auto object-contain rounded-lg shadow-sm"
            />
          </div>
          <span className="text-xl font-bold text-[#E2136E] tracking-tight">আমার লোন</span>
        </div>
        <nav className="hidden md:flex space-x-6 text-sm font-medium text-gray-600">
          <a href="#" className="hover:text-[#E2136E] transition-colors">হোম</a>
          <a href="#" className="hover:text-[#E2136E] transition-colors">আমাদের সম্পর্কে</a>
          <a href="#" className="hover:text-[#E2136E] transition-colors">শর্তাবলী</a>
          <a href="#" className="hover:text-[#E2136E] transition-colors">যোগাযোগ</a>
        </nav>
      </div>
    </header>
  );
};

export default Header;
