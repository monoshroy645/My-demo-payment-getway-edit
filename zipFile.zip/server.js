
const express = require('express');
const Database = require('@replit/database');
const cors = require('cors');
const path = require('path');

const app = express();
const db = new Database();

app.use(cors());
app.use(express.json());

// Serve static files from the root
app.use(express.static(__dirname));

// DB Proxy Endpoints
app.get('/api/db', async (req, res) => {
  const { path: dbPath } = req.query;
  try {
    const data = await db.get(dbPath);
    res.json(data || null);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/db', async (req, res) => {
  const { path: dbPath, data } = req.body;
  try {
    await db.set(dbPath, data);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.patch('/api/db', async (req, res) => {
  const { path: dbPath, data } = req.body;
  try {
    const existing = await db.get(dbPath) || {};
    const updated = { ...existing, ...data };
    await db.set(dbPath, updated);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/db', async (req, res) => {
  const { path: dbPath } = req.query;
  try {
    await db.delete(dbPath);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Admin endpoint to list all sessions
app.get('/api/sessions', async (req, res) => {
  try {
    const keys = await db.list('sessions/');
    const sessions = {};
    for (const key of keys) {
      sessions[key.replace('sessions/', '')] = await db.get(key);
    }
    res.json(sessions);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/sessions/all', async (req, res) => {
  try {
    const keys = await db.list('sessions/');
    for (const key of keys) {
      await db.delete(key);
    }
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
